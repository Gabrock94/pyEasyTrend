# pyEasyTrend
A simple entrypoint to perform a trend analysis in Python

![Upload Python Package](https://github.com/Gabrock94/pyEasyTrend/workflows/Upload%20Python%20Package/badge.svg)
